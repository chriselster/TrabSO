function start(){
    time = 0;
    frameRate(2);
    resizeCanvas(width, height+(tam-1)*(size+size*0.2));
}